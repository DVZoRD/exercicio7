#include<stdio.h>


int main()
{
    
int n , seq = 0 ;

printf("Digite um numero:");
scanf("%d" , &n);

while(seq <= n ){

    printf("\n %d" , seq);

    seq++;

}






   
}
